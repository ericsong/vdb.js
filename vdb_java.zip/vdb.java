// Created by Albert Pan

package yhack;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class vdb {

private String server_name;
	
	public  void setServer(String name) {
		server_name = name;
	}
	
	public void drawTree(Object obj) {
		JSONObject o = new JSONObject();
		o = add(obj, o, 1);
		try {
			sendPost(o.toJSONString());
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// HTTP POST request
	public void sendPost(String s) throws Exception {
 
		HttpClient client = new DefaultHttpClient();
		HttpPost post = new HttpPost(server_name);
	 
		// add header
	 
		ArrayList<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
		urlParameters.add(new BasicNameValuePair("JSON", s));
		post.setEntity(new UrlEncodedFormEntity(urlParameters));
	 
		HttpResponse response = client.execute(post);
		System.out.println("\nSending 'POST' request to URL : " + server_name);
		System.out.println("Post parameters : " + post.getEntity());
		System.out.println("Response Code : " + 
                                    response.getStatusLine().getStatusCode());
	 
		BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
	 
		StringBuffer result = new StringBuffer();
		String line = "";
		while ((line = rd.readLine()) != null) {
			result.append(line);
		}
	 
		System.out.println(result.toString());
	}

	public JSONObject add(Object obj, JSONObject j, int count) {
		if (obj != null) {
			Field[] fields = obj.getClass().getDeclaredFields();
			j.put("name", "node" + Integer.toString(count));
			JSONArray children = new JSONArray();
			JSONArray data = new JSONArray();
			for (Field f : fields) {
				try {
					if (f.getType().equals(new ArrayList().getClass())){
						for (int i = 0; i < ((ArrayList) f.get(obj)).size(); i++) {
							children.add(add(((ArrayList) f.get(obj)).get(i), new JSONObject(), ++count));
							j.put("children", children);
						}
					}
					else if (!f.getType().equals(obj.getClass())) {
						JSONObject d = new JSONObject();
						d.put("name", f.getName());
						d.put("value", f.get(obj));
						data.add(d);
						j.put("data", data);
					}
					else if (f.get(obj) != null) {
						children.add(add(f.get(obj), new JSONObject(), ++count));
						j.put("children", children);
					}
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return j;
	}
	
}
